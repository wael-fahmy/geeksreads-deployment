define({
  "name": "",
  "version": "0.0.0",
  "description": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-05-02T17:53:16.951Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
